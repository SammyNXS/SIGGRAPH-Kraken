﻿using UnityEngine;
using System.Collections;

public class FlowingFlame : Shot {

	Transform player;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void GetQuadraticCoordinates()
	{
		//Mathf.Pow (1-t,2)*p0+2*t*(1-t)*c0+Mathf.Pow(t,2)*p1;
	}
}
